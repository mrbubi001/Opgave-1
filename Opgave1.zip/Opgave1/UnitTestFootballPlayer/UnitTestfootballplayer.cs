using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ClassLibraryopl;


namespace UnitTestFootballPlayer
{
    [TestClass]
    public class UnitTestfootballplayer
    {
        [TestClass()]
        public class FootballPlayerTests
        {
            private FootballPlayer _footballPlayer;

            [TestInitialize]
            public void FootballPlayer1()
            {
                _footballPlayer = new FootballPlayer("Messi", 1000000, 10);
            }

            [TestMethod]
            public void NameTest()
            {
                Assert.AreEqual("Messi", _footballPlayer.Name);
                _footballPlayer.Name = "patrick";
                Assert.AreEqual("patrick", _footballPlayer.Name);
            }

            [TestMethod]
            public void PriceTest()
            {
                Assert.AreEqual(1000000, _footballPlayer.Price);
                _footballPlayer.Price = 500000;
                Assert.AreEqual(500000, _footballPlayer.Price);
            }

            [TestMethod]
            [ExpectedException(typeof(ArgumentException))]
            public void PriceTest2()
            {
                _footballPlayer.Price = -100000;
            }

            [TestMethod]
            public void ShirtnumberTest()
            {
                Assert.AreEqual(10, _footballPlayer.ShirtNumber);
                _footballPlayer.ShirtNumber = 8;
                Assert.AreEqual(8, _footballPlayer.ShirtNumber);
            }

            [TestMethod]
            [ExpectedException(typeof(ArgumentOutOfRangeException))]
            public void ShirtnumberTest2()
            {
                _footballPlayer.ShirtNumber = -10;
            }
        }

    }
}
